import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:crypto/crypto.dart';
import 'package:gal/gal.dart';
import 'package:path_provider/path_provider.dart';
import 'package:http/http.dart' as http;
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:just_audio/just_audio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

// ===== KONFIGURASI API (KuroNeko - sylvatica.my.id) =====
const apiUrl = 'https://sylvatica.my.id/api/ai/kuroneko';
const tmUrl = 'https://sylvatica.my.id/api/tools/tempmail';
const apiKey = 'sylva-706cf22aaa2b0edf596a9eb29b0e1967';
// =========================================================

const bg = Color(0xFF060F14);
const card = Color(0xFF101B21);
const purple = Color(0xFF22D3EE);
const green = Color(0xFF2ECC9A);

class Character {
  final String name, persona, emoji;
  const Character(this.name, this.persona, this.emoji);
}

const characters = [
  Character('Daxter AI', 'Kamu adalah Daxter, karakter roleplay yang misterius, cerdas, dan humoris. Balas dalam bahasa Indonesia, gaya narasi roleplay.', '🃏'),
  Character('Luna', 'Kamu adalah Luna, penyihir ramah dari hutan perak. Balas dengan deskripsi aksi dalam tanda * * dan dialog.', '🌙'),
  Character('Kael', 'Kamu adalah Kael, ksatria dingin yang setia. Balas singkat, tegas, bergaya roleplay.', '⚔️'),
];

const stories = [
  ('Kastil Terlarang', 'Kamu terbangun di kastil tua tanpa ingatan. Narasikan petualangannya.'),
  ('Akademi Sihir', 'Kamu murid baru di akademi sihir. Jadilah game master yang seru.'),
  ('Kota Cyberpunk', 'Kamu detektif di kota cyberpunk 2099. Buat misteri yang menegangkan.'),
];

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Auth.init();
  Music.init();
  Stories.init();
  runApp(const DaxterApp());
}

class DaxterApp extends StatelessWidget {
  const DaxterApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Daxter Project',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: bg,
          colorScheme: const ColorScheme.dark(primary: purple),
          appBarTheme: const AppBarTheme(backgroundColor: bg, centerTitle: true, elevation: 0),
          drawerTheme: const DrawerThemeData(backgroundColor: bg),
        ),
        home: ValueListenableBuilder<String?>(
          valueListenable: Auth.current,
          builder: (_, u, __) => u == null ? const AuthPage() : const Shell(),
        ),
      );
}

// ---------------- API ----------------
String _extract(dynamic d) {
  if (d is String) return d;
  if (d is Map) {
    for (final k in ['reply', 'response', 'message', 'result', 'text', 'answer', 'content', 'data']) {
      if (d[k] != null) {
        final r = _extract(d[k]);
        if (r.isNotEmpty) return r;
      }
    }
    if (d['choices'] is List && d['choices'].isNotEmpty) return _extract(d['choices'][0]);
  }
  return '';
}

String _session(dynamic d) {
  if (d is Map) {
    for (final k in ['session', 'session_id', 'sessionId', 'sessionid']) {
      if (d[k] != null && d[k].toString().isNotEmpty) return d[k].toString();
    }
    for (final k in ['result', 'data']) {
      final r = _session(d[k]);
      if (r.isNotEmpty) return r;
    }
  }
  return '';
}

/// GET apiUrl?q=...&session=...&apikey=...  -> (balasan, session)
Future<(String, String)> askAi(String persona, String text, String session) async {
  try {
    // KuroNeko tidak punya field system, jadi persona disisipkan di pesan pertama
    final q = session.isEmpty ? '[Peran/Persona: $persona]\n\n$text' : text;
    final uri = Uri.parse(apiUrl).replace(queryParameters: {
      'q': q,
      'apikey': apiKey,
      if (session.isNotEmpty) 'session': session,
    });
    final res = await http.get(uri).timeout(const Duration(seconds: 60));
    dynamic d;
    try {
      d = jsonDecode(res.body);
    } catch (_) {
      d = res.body;
    }
    if (d is Map && (d['status'] == false || d['success'] == false)) {
      return ('⚠️ ${d['message'] ?? d['error'] ?? 'API menolak permintaan'}', session);
    }
    if (res.statusCode != 200) return ('⚠️ Server error (${res.statusCode})', session);
    final out = _extract(d);
    final ses = _session(d);
    return (out.isEmpty ? '⚠️ Respon kosong dari API' : out, ses.isEmpty ? session : ses);
  } catch (e) {
    return ('⚠️ Gagal terhubung: $e', session);
  }
}

// ---------------- SHELL + DRAWER ----------------
class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int idx = 0;
  final key = GlobalKey<ScaffoldState>();

  static const menu = [
    ('UTAMA', null, null),
    ('Home', Icons.home_outlined, 0),
    ('Bug', Icons.bug_report_outlined, 1),
    ('CHAT', null, null),
    ('Messages', Icons.mail_outline, 2),
    ('Global Chat', Icons.forum_outlined, 3),
    ('Story', Icons.auto_stories_outlined, 4),
    ('SHOP', null, null),
    ('Daxter Shop', Icons.shopping_cart_outlined, 5),
    ('Flash Sale', Icons.bolt, 6),
    ('Reseller Shop', Icons.handshake_outlined, 7),
    ('Riwayat Kode', Icons.history, 8),
    ('GAME', null, null),
    ('Dead Zone Commando', Icons.sports_esports_outlined, 11),
    ('TOOLS', null, null),
    ('Music Player', Icons.library_music_outlined, 9),
    ('Download TikTok', Icons.download_outlined, 12),
    ('Temp Mail', Icons.alternate_email, 13),
    ('Pengaturan', Icons.settings_outlined, 10),
  ];

  void go(int i) => setState(() => idx = i);

  Widget page() {
    switch (idx) {
      case 0:
        return HomePage(go: go);
      case 1:
        return const BugPage();
      case 2:
        return const MessagesPage();
      case 3:
        return ChatView(character: characters[0]);
      case 4:
        return const StoryPage();
      case 5:
        return const InfoList(items: ['Premium 7 Hari — Rp 5.000', 'Premium 30 Hari — Rp 15.000', 'Slot Karakter — Rp 3.000']);
      case 6:
        return const InfoList(items: ['⚡ Premium 30 Hari — Rp 9.900', '⚡ Slot Karakter x3 — Rp 5.000']);
      case 7:
        return const InfoList(items: ['Paket Reseller 30 Hari — Rp 50.000', 'Paket Reseller 90 Hari — Rp 120.000']);
      case 8:
        return const InfoList(items: ['Belum ada riwayat kode']);
      case 9:
        return const MusicPage();
      case 12:
        return const TikTokPage();
      case 13:
        return const TempMailPage();
      default:
        return const SettingsPage();
    }
  }

  String get title => menu.firstWhere((m) => m.$3 == idx).$1;

  @override
  Widget build(BuildContext context) => Scaffold(
        key: key,
        appBar: AppBar(
          leading: IconButton(icon: const Icon(Icons.menu), onPressed: () => key.currentState!.openDrawer()),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          actions: [
            IconButton(icon: const Icon(Icons.person_outline), onPressed: () => go(10)),
            IconButton(
                icon: const Icon(Icons.notifications_none),
                onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Tidak ada notifikasi')))),
          ],
        ),
        drawer: Drawer(
          child: SafeArea(
            child: Column(children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: Colors.white12))),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  ValueListenableBuilder<Map<String, dynamic>>(
                    valueListenable: Auth.profile,
                    builder: (_, p, __) => Text('${p['name'] ?? ''}', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                  ),
                  const SizedBox(height: 10),
                  Wrap(spacing: 8, children: [
                    chip('RP · Tidak aktif'),
                    chip('RESELLER · 06/10/2026'),
                  ]),
                ]),
              ),
              Expanded(
                child: ListView(padding: const EdgeInsets.all(12), children: [
                  for (final m in menu)
                    if (m.$2 == null)
                      Padding(
                        padding: const EdgeInsets.fromLTRB(8, 16, 8, 6),
                        child: Text(m.$1, style: const TextStyle(color: Colors.white54, fontWeight: FontWeight.w600)),
                      )
                    else
                      Container(
                        margin: const EdgeInsets.symmetric(vertical: 2),
                        decoration: BoxDecoration(
                            color: idx == m.$3 ? const Color(0xFF0E2F38) : null, borderRadius: BorderRadius.circular(16)),
                        child: ListTile(
                          leading: Icon(m.$2, color: idx == m.$3 ? purple : Colors.white70),
                          title: Text(m.$1, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
                          trailing: idx == m.$3 ? const Icon(Icons.chevron_right, color: purple) : null,
                          onTap: () {
                            Navigator.pop(context);
                            if (m.$3 == 11) {
                              Navigator.push(context, MaterialPageRoute(builder: (_) => const GamePage()));
                            } else {
                              go(m.$3 as int);
                            }
                          },
                        ),
                      ),
                ]),
              ),
              ListTile(
                leading: const Icon(Icons.logout, color: Colors.redAccent),
                title: const Text('Keluar', style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.w600)),
                onTap: Auth.logout,
              ),
              const Padding(padding: EdgeInsets.all(12), child: Text('Daxter Project', style: TextStyle(color: Colors.white54))),
            ]),
          ),
        ),
        body: page(),
      );

  Widget chip(String t) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(border: Border.all(color: Colors.white24), borderRadius: BorderRadius.circular(20)),
        child: Text(t, style: const TextStyle(fontSize: 12, color: Colors.white70)),
      );
}

// ---------------- HOME ----------------
class HomePage extends StatefulWidget {
  final void Function(int) go;
  const HomePage({super.key, required this.go});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late Timer t;
  DateTime now = DateTime.now();
  @override
  void initState() {
    super.initState();
    t = Timer.periodic(const Duration(seconds: 1), (_) => setState(() => now = DateTime.now()));
  }

  @override
  void dispose() {
    t.cancel();
    super.dispose();
  }

  String two(int n) => n.toString().padLeft(2, '0');

  BoxDecoration box() => BoxDecoration(color: card, borderRadius: BorderRadius.circular(28), border: Border.all(color: Colors.white10));

  Widget pill(String t, {Color c = Colors.white24, IconData? i}) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(border: Border.all(color: c), borderRadius: BorderRadius.circular(20)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          if (i != null) Icon(i, size: 16, color: c),
          if (i != null) const SizedBox(width: 6),
          Text(t, style: TextStyle(color: c == Colors.white24 ? Colors.white70 : c, fontWeight: FontWeight.w600)),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    const days = ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'];
    const mon = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
    return ListView(padding: const EdgeInsets.all(16), children: [
      Container(
        height: 190,
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(28), color: card),
        child: Stack(children: [
          const Positioned.fill(child: BannerVideo()),
          const Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Color(0xCC000000)]),
              ),
            ),
          ),
          Positioned(
            left: 20,
            bottom: 18,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Daxter Project', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              Text('${days[now.weekday - 1]}, ${now.day} ${mon[now.month - 1]} ${now.year}', style: const TextStyle(color: Colors.white70)),
            ]),
          ),
          Positioned(
            right: 20,
            bottom: 18,
            child: Text('${two(now.hour)}:${two(now.minute)} WIB', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          ),
        ]),
      ),
      const SizedBox(height: 16),
      Container(
        padding: const EdgeInsets.all(18),
        decoration: box(),
        child: Column(children: [
          Row(children: [
            const UserAvatar(radius: 32),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('SALAM,', style: TextStyle(color: purple, letterSpacing: 3, fontWeight: FontWeight.bold, fontSize: 12)),
                ValueListenableBuilder<Map<String, dynamic>>(
                  valueListenable: Auth.profile,
                  builder: (_, p, __) => Text('${p['name'] ?? ''}',
                      maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
                ),
              ]),
            ),
            pill('RESELLER', c: Colors.redAccent),
          ]),
          const Divider(height: 28, color: Colors.white12),
          Align(
            alignment: Alignment.centerLeft,
            child: Wrap(spacing: 10, runSpacing: 10, children: [
              pill('RP · Tidak aktif', i: Icons.circle),
              pill('06/10/2026', i: Icons.calendar_today_outlined),
              pill('Wallet · Rp 500', c: green, i: Icons.account_balance_wallet_outlined),
            ]),
          ),
        ]),
      ),
      const SizedBox(height: 20),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        const Text('STATUS', style: TextStyle(color: Colors.white54, letterSpacing: 2, fontWeight: FontWeight.bold)),
        GestureDetector(onTap: () => widget.go(4), child: const Text('Lihat semua', style: TextStyle(color: purple, fontWeight: FontWeight.bold))),
      ]),
      const SizedBox(height: 10),
      SizedBox(
        height: 110,
        child: ListView(scrollDirection: Axis.horizontal, children: [
          status('Status saya', '➕'),
          for (final c in characters) status(c.name, c.emoji),
        ]),
      ),
      const SizedBox(height: 14),
      const Text('NOW PLAYING', style: TextStyle(color: Colors.white54, fontSize: 17, fontWeight: FontWeight.w600)),
      const SizedBox(height: 8),
      InkWell(
        borderRadius: BorderRadius.circular(28),
        onTap: () => widget.go(9),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: box(),
          child: ValueListenableBuilder<int>(
            valueListenable: Music.index,
            builder: (_, i, __) {
              final has = i >= 0 && i < Music.tracks.value.length;
              return Row(children: [
                const CircleAvatar(radius: 30, backgroundColor: Color(0xFF14391F), child: Icon(Icons.music_note, color: green, size: 30)),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(has ? Music.tracks.value[i]['title']! : 'Belum ada lagu',
                        maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 20, color: has ? Colors.white : Colors.white54, fontWeight: FontWeight.bold)),
                    Text(has ? 'Sedang diputar' : 'Buka Music library', style: const TextStyle(color: Colors.white38)),
                  ]),
                ),
                const Icon(Icons.chevron_right, color: Colors.white54),
              ]);
            },
          ),
        ),
      ),
      const SizedBox(height: 16),
      Container(
        padding: const EdgeInsets.all(18),
        decoration: box(),
        child: Column(children: [
          const Row(children: [
            CircleAvatar(backgroundColor: Color(0xFF0E2F38), child: Icon(Icons.public, color: purple)),
            SizedBox(width: 14),
            Expanded(child: Text('Global Chat', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
            Icon(Icons.circle, color: Colors.green, size: 14),
          ]),
          const SizedBox(height: 14),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(border: Border.all(color: Colors.white12), borderRadius: BorderRadius.circular(20)),
            child: const Text('Daxter AI: Siap memulai roleplay?', style: TextStyle(fontSize: 16)),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: const Color(0xFF0E2F38),
                  side: const BorderSide(color: purple),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
              onPressed: () => widget.go(3),
              icon: const Icon(Icons.chat_bubble_outline),
              label: const Text('Buka', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
          ),
        ]),
      ),
      const SizedBox(height: 80),
    ]);
  }

  Widget status(String n, String e) => GestureDetector(
        onTap: () {
          if (n == 'Status saya') {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const StoryComposePage()));
            return;
          }
          final c = characters.where((c) => c.name == n);
          if (c.isNotEmpty) Navigator.push(context, MaterialPageRoute(builder: (_) => ChatPage(character: c.first)));
        },
        child: Padding(
          padding: const EdgeInsets.only(right: 14),
          child: Column(children: [
            Container(
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: green, width: 3)),
              child: CircleAvatar(radius: 30, backgroundColor: card, child: Text(e, style: const TextStyle(fontSize: 26))),
            ),
            const SizedBox(height: 6),
            Text(n, style: const TextStyle(fontWeight: FontWeight.w600)),
          ]),
        ),
      );
}

// ---------------- PAGES ----------------
class MessagesPage extends StatelessWidget {
  const MessagesPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
        for (final c in characters)
          Card(
            color: card,
            margin: const EdgeInsets.only(bottom: 12),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            child: ListTile(
              contentPadding: const EdgeInsets.all(14),
              leading: CircleAvatar(radius: 26, backgroundColor: bg, child: Text(c.emoji, style: const TextStyle(fontSize: 24))),
              title: Text(c.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
              subtitle: const Text('Ketuk untuk mulai roleplay'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatPage(character: c))),
            ),
          ),
      ]);
}

const storyColors = [0xFF0E5566, 0xFF4A1A6A, 0xFF7A1A2A, 0xFF1A5A3A, 0xFF5A4A1A, 0xFF22313A];

class Stories {
  static final list = ValueNotifier<List<Map<String, dynamic>>>([]);
  static const day = 86400000;

  static void init() {
    final j = Auth.p.getString('stories');
    if (j == null) return;
    list.value = (jsonDecode(j) as List).map((e) => Map<String, dynamic>.from(e)).toList();
  }

  static List<Map<String, dynamic>> active() {
    final cut = DateTime.now().millisecondsSinceEpoch - day;
    return list.value.where((e) => (e['ts'] as int) > cut).toList();
  }

  static Future<void> _save() => Auth.p.setString('stories', jsonEncode(active()));

  static Future<void> add(String text, int color) async {
    list.value = [
      {'user': Auth.current.value, 'name': '${Auth.profile.value['name'] ?? ''}', 'text': text, 'color': color, 'ts': DateTime.now().millisecondsSinceEpoch},
      ...active(),
    ];
    await _save();
  }

  static Future<void> remove(int ts) async {
    list.value = active().where((e) => e['ts'] != ts).toList();
    await _save();
  }

  static String ago(int ts) {
    final m = (DateTime.now().millisecondsSinceEpoch - ts) ~/ 60000;
    if (m < 1) return 'baru saja';
    if (m < 60) return '$m menit lalu';
    return '${m ~/ 60} jam lalu';
  }
}

class StoryComposePage extends StatefulWidget {
  const StoryComposePage({super.key});
  @override
  State<StoryComposePage> createState() => _StoryComposePageState();
}

class _StoryComposePageState extends State<StoryComposePage> {
  final c = TextEditingController();
  int color = storyColors[0];

  Future<void> post() async {
    if (c.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Tulis sesuatu dulu')));
      return;
    }
    await Stories.add(c.text.trim(), color);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Buat Story', style: TextStyle(fontWeight: FontWeight.bold))),
        body: Column(children: [
          Expanded(
            child: Container(
              width: double.infinity,
              color: Color(color),
              alignment: Alignment.center,
              padding: const EdgeInsets.all(24),
              child: TextField(
                controller: c,
                maxLength: 300,
                maxLines: null,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                decoration: const InputDecoration(hintText: 'Ketik story kamu...', border: InputBorder.none, counterStyle: TextStyle(color: Colors.white54)),
              ),
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(children: [
                for (final k in storyColors)
                  GestureDetector(
                    onTap: () => setState(() => color = k),
                    child: Container(
                      width: 34,
                      height: 34,
                      margin: const EdgeInsets.only(right: 8),
                      decoration: BoxDecoration(shape: BoxShape.circle, color: Color(k), border: Border.all(color: color == k ? purple : Colors.white24, width: color == k ? 3 : 1)),
                    ),
                  ),
                const Spacer(),
                FilledButton.icon(
                  style: FilledButton.styleFrom(backgroundColor: purple, foregroundColor: Colors.black),
                  onPressed: post,
                  icon: const Icon(Icons.send),
                  label: const Text('Kirim', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
              ]),
            ),
          ),
        ]),
      );
}

class StoryViewer extends StatelessWidget {
  final List<Map<String, dynamic>> items;
  final int start;
  const StoryViewer({super.key, required this.items, required this.start});
  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        body: PageView.builder(
          controller: PageController(initialPage: start),
          itemCount: items.length,
          itemBuilder: (_, i) {
            final s = items[i];
            final mine = s['user'] == Auth.current.value;
            return Container(
              color: Color(s['color'] as int),
              child: SafeArea(
                child: Stack(children: [
                  Center(child: Padding(padding: const EdgeInsets.all(28), child: Text('${s['text']}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)))),
                  Positioned(
                    top: 10,
                    left: 10,
                    right: 10,
                    child: Row(children: [
                      IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(context)),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('${s['name']}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                          Text(Stories.ago(s['ts'] as int), style: const TextStyle(color: Colors.white70, fontSize: 12)),
                        ]),
                      ),
                      if (mine)
                        IconButton(
                          icon: const Icon(Icons.delete_outline),
                          onPressed: () async {
                            await Stories.remove(s['ts'] as int);
                            if (context.mounted) Navigator.pop(context);
                          },
                        ),
                    ]),
                  ),
                ]),
              ),
            );
          },
        ),
      );
}

class StoryPage extends StatelessWidget {
  const StoryPage({super.key});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<List<Map<String, dynamic>>>(
        valueListenable: Stories.list,
        builder: (_, __, ___) {
          final items = Stories.active();
          return ListView(padding: const EdgeInsets.all(16), children: [
            FilledButton.icon(
              style: FilledButton.styleFrom(padding: const EdgeInsets.all(16), backgroundColor: purple, foregroundColor: Colors.black),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const StoryComposePage())),
              icon: const Icon(Icons.edit),
              label: const Text('Buat Story', style: TextStyle(fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 18),
            const Text('STORY TERBARU · 24 JAM', style: TextStyle(color: Colors.white54, letterSpacing: 2, fontWeight: FontWeight.bold, fontSize: 12)),
            const SizedBox(height: 10),
            if (items.isEmpty)
              const Padding(padding: EdgeInsets.all(20), child: Center(child: Text('Belum ada story', style: TextStyle(color: Colors.white38))))
            else
              SizedBox(
                height: 190,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: items.length,
                  itemBuilder: (_, i) {
                    final s = items[i];
                    return GestureDetector(
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => StoryViewer(items: items, start: i))),
                      child: Container(
                        width: 130,
                        margin: const EdgeInsets.only(right: 12),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(color: Color(s['color'] as int), borderRadius: BorderRadius.circular(22), border: Border.all(color: Colors.white12)),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Expanded(child: Text('${s['text']}', maxLines: 6, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold))),
                          Text('${s['name']}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                          Text(Stories.ago(s['ts'] as int), style: const TextStyle(fontSize: 11, color: Colors.white70)),
                        ]),
                      ),
                    );
                  },
                ),
              ),
            const SizedBox(height: 22),
            const Text('SKENARIO ROLEPLAY', style: TextStyle(color: Colors.white54, letterSpacing: 2, fontWeight: FontWeight.bold, fontSize: 12)),
            const SizedBox(height: 10),
            for (final s in stories)
              Card(
                color: card,
                margin: const EdgeInsets.only(bottom: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                child: ListTile(
                  contentPadding: const EdgeInsets.all(16),
                  leading: const Icon(Icons.auto_stories, color: purple, size: 30),
                  title: Text(s.$1, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                  subtitle: Text(s.$2),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatPage(character: Character(s.$1, s.$2, '📖')))),
                ),
              ),
          ]);
        },
      );
}

class BugPage extends StatelessWidget {
  const BugPage({super.key});
  @override
  Widget build(BuildContext context) {
    final c = TextEditingController();
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(children: [
        TextField(
          controller: c,
          maxLines: 6,
          decoration: InputDecoration(
              hintText: 'Jelaskan bug yang kamu temukan...', filled: true, fillColor: card, border: OutlineInputBorder(borderRadius: BorderRadius.circular(20))),
        ),
        const SizedBox(height: 14),
        SizedBox(
          width: double.infinity,
          child: FilledButton(
            style: FilledButton.styleFrom(padding: const EdgeInsets.all(16)),
            onPressed: () {
              c.clear();
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Laporan terkirim. Terima kasih!')));
            },
            child: const Text('Kirim Laporan'),
          ),
        ),
      ]),
    );
  }
}

class InfoList extends StatelessWidget {
  final List<String> items;
  const InfoList({super.key, required this.items});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
        for (final i in items)
          Card(
            color: card,
            margin: const EdgeInsets.only(bottom: 12),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            child: ListTile(
              contentPadding: const EdgeInsets.all(16),
              title: Text(i, style: const TextStyle(fontWeight: FontWeight.w600)),
              onTap: () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(i))),
            ),
          ),
      ]);
}

class Music {
  static final player = AudioPlayer();
  static final tracks = ValueNotifier<List<Map<String, String>>>([]);
  static final index = ValueNotifier<int>(-1);

  static void init() {
    final j = Auth.p.getString('music');
    if (j != null) {
      tracks.value = (jsonDecode(j) as List).map((e) => Map<String, String>.from(e)).toList();
    }
    player.processingStateStream.listen((st) {
      if (st == ProcessingState.completed) next();
    });
  }

  static Future<void> _save() => Auth.p.setString('music', jsonEncode(tracks.value));

  static Future<int> add() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.audio, allowMultiple: true);
    if (r == null) return 0;
    final l = [...tracks.value];
    var n = 0;
    for (final f in r.files) {
      if (f.path == null) continue;
      l.add({'title': f.name.replaceAll(RegExp(r'\.[^.]+$'), ''), 'path': f.path!});
      n++;
    }
    tracks.value = l;
    await _save();
    return n;
  }

  static Future<String?> play(int i) async {
    if (i < 0 || i >= tracks.value.length) return null;
    index.value = i;
    try {
      await player.setFilePath(tracks.value[i]['path']!);
      player.play();
      return null;
    } catch (e) {
      return 'Gagal memutar lagu (file mungkin sudah dihapus)';
    }
  }

  static void next() {
    final n = tracks.value.length;
    if (n > 0) play((index.value + 1) % n);
  }

  static void prev() {
    final n = tracks.value.length;
    if (n > 0) play((index.value - 1 + n) % n);
  }

  static Future<void> remove(int i) async {
    final cur = index.value;
    final l = [...tracks.value]..removeAt(i);
    if (i == cur) {
      await player.stop();
      index.value = -1;
    } else if (i < cur) {
      index.value = cur - 1;
    }
    tracks.value = l;
    await _save();
  }
}

class MusicPage extends StatelessWidget {
  const MusicPage({super.key});

  String fmt(Duration d) => '${d.inMinutes}:${(d.inSeconds % 60).toString().padLeft(2, '0')}';
  void toast(BuildContext c, String t) => ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(t)));

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<List<Map<String, String>>>(
        valueListenable: Music.tracks,
        builder: (_, list, __) => ValueListenableBuilder<int>(
          valueListenable: Music.index,
          builder: (_, cur, __) {
            final has = cur >= 0 && cur < list.length;
            return ListView(padding: const EdgeInsets.all(16), children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(28), border: Border.all(color: Colors.white10)),
                child: Column(children: [
                  const CircleAvatar(radius: 46, backgroundColor: Color(0xFF14391F), child: Icon(Icons.music_note, size: 46, color: green)),
                  const SizedBox(height: 14),
                  Text(has ? list[cur]['title']! : 'Belum ada lagu',
                      maxLines: 2, textAlign: TextAlign.center, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: has ? Colors.white : Colors.white54)),
                  StreamBuilder<Duration?>(
                    stream: Music.player.durationStream,
                    builder: (_, ds) {
                      final dur = ds.data ?? Duration.zero;
                      return StreamBuilder<Duration>(
                        stream: Music.player.positionStream,
                        builder: (_, ps) {
                          final pos = ps.data ?? Duration.zero;
                          final max = dur.inMilliseconds.toDouble();
                          return Column(children: [
                            Slider(
                              value: max > 0 ? pos.inMilliseconds.clamp(0, dur.inMilliseconds).toDouble() : 0,
                              max: max > 0 ? max : 1,
                              onChanged: has && max > 0 ? (v) => Music.player.seek(Duration(milliseconds: v.toInt())) : null,
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 16),
                              child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                                Text(fmt(pos), style: const TextStyle(color: Colors.white54, fontSize: 12)),
                                Text(fmt(dur), style: const TextStyle(color: Colors.white54, fontSize: 12)),
                              ]),
                            ),
                          ]);
                        },
                      );
                    },
                  ),
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    IconButton(iconSize: 36, icon: const Icon(Icons.skip_previous), onPressed: list.isEmpty ? null : Music.prev),
                    StreamBuilder<PlayerState>(
                      stream: Music.player.playerStateStream,
                      builder: (_, st) {
                        final playing = st.data?.playing ?? false;
                        return IconButton(
                          iconSize: 64,
                          color: purple,
                          icon: Icon(playing ? Icons.pause_circle : Icons.play_circle),
                          onPressed: list.isEmpty
                              ? null
                              : () async {
                                  if (!has) {
                                    final e = await Music.play(0);
                                    if (e != null && context.mounted) toast(context, e);
                                  } else if (playing) {
                                    Music.player.pause();
                                  } else {
                                    Music.player.play();
                                  }
                                },
                        );
                      },
                    ),
                    IconButton(iconSize: 36, icon: const Icon(Icons.skip_next), onPressed: list.isEmpty ? null : Music.next),
                  ]),
                ]),
              ),
              const SizedBox(height: 14),
              FilledButton.icon(
                style: FilledButton.styleFrom(padding: const EdgeInsets.all(16), backgroundColor: purple, foregroundColor: Colors.black),
                onPressed: () async {
                  final n = await Music.add();
                  if (n > 0 && context.mounted) toast(context, '$n lagu ditambahkan');
                },
                icon: const Icon(Icons.library_add),
                label: const Text('Tambah Lagu dari HP', style: TextStyle(fontWeight: FontWeight.bold)),
              ),
              const SizedBox(height: 14),
              if (list.isEmpty)
                const Padding(padding: EdgeInsets.all(24), child: Center(child: Text('Playlist kosong', style: TextStyle(color: Colors.white38)))),
              for (var i = 0; i < list.length; i++)
                Card(
                  color: i == cur ? const Color(0xFF0E2F38) : card,
                  margin: const EdgeInsets.only(bottom: 8),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  child: ListTile(
                    leading: Icon(i == cur ? Icons.equalizer : Icons.music_note, color: i == cur ? purple : Colors.white54),
                    title: Text(list[i]['title']!, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: i == cur ? FontWeight.bold : FontWeight.normal)),
                    trailing: IconButton(icon: const Icon(Icons.close, size: 20), onPressed: () => Music.remove(i)),
                    onTap: () async {
                      final e = await Music.play(i);
                      if (e != null && context.mounted) toast(context, e);
                    },
                  ),
                ),
            ]);
          },
        ),
      );
}

// ---------------- CHAT ROLEPLAY ----------------
class ChatPage extends StatelessWidget {
  final Character character;
  const ChatPage({super.key, required this.character});
  @override
  Widget build(BuildContext context) =>
      Scaffold(appBar: AppBar(title: Text(character.name)), body: ChatView(character: character));
}

class ChatView extends StatefulWidget {
  final Character character;
  const ChatView({super.key, required this.character});
  @override
  State<ChatView> createState() => _ChatViewState();
}

class _ChatViewState extends State<ChatView> {
  final msgs = <Map<String, String>>[];
  final ctrl = TextEditingController();
  final scroll = ScrollController();
  bool loading = false;
  String session = '';

  Future<void> send() async {
    final t = ctrl.text.trim();
    if (t.isEmpty || loading) return;
    ctrl.clear();
    setState(() {
      msgs.add({'role': 'user', 'content': t});
      loading = true;
    });
    _down();
    final custom = '${Auth.profile.value['persona'] ?? ''}'.trim();
    final persona = custom.isEmpty ? widget.character.persona : '${widget.character.persona}\n\nInstruksi persona tambahan dari pengguna (wajib diikuti): $custom';
    final (r, ses) = await askAi(persona, t, session);
    if (!mounted) return;
    setState(() {
      session = ses;
      msgs.add({'role': 'assistant', 'content': r});
      loading = false;
    });
    _down();
  }

  void _down() => WidgetsBinding.instance.addPostFrameCallback((_) {
        if (scroll.hasClients) scroll.animateTo(scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      });

  @override
  Widget build(BuildContext context) => Column(children: [
        Expanded(
          child: msgs.isEmpty
              ? Center(child: Text('${widget.character.emoji}\nMulai roleplay dengan ${widget.character.name}', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white54, fontSize: 16)))
              : ListView.builder(
                  controller: scroll,
                  padding: const EdgeInsets.all(16),
                  itemCount: msgs.length,
                  itemBuilder: (_, i) {
                    final me = msgs[i]['role'] == 'user';
                    return Align(
                      alignment: me ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.8),
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(color: me ? purple : card, borderRadius: BorderRadius.circular(20)),
                        child: SelectableText(msgs[i]['content']!),
                      ),
                    );
                  },
                ),
        ),
        if (loading) const LinearProgressIndicator(color: purple),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              Expanded(
                child: TextField(
                  controller: ctrl,
                  onSubmitted: (_) => send(),
                  decoration: InputDecoration(
                      hintText: 'Tulis pesan roleplay...', filled: true, fillColor: card, border: OutlineInputBorder(borderRadius: BorderRadius.circular(28), borderSide: BorderSide.none)),
                ),
              ),
              const SizedBox(width: 8),
              CircleAvatar(radius: 24, backgroundColor: purple, child: IconButton(icon: const Icon(Icons.send, color: Colors.white), onPressed: send)),
            ]),
          ),
        ),
      ]);
}

// ---------------- AUTH (lokal, tanpa database server) ----------------
class Auth {
  static late SharedPreferences p;
  static final current = ValueNotifier<String?>(null);
  static final profile = ValueNotifier<Map<String, dynamic>>({});

  static Map<String, dynamic> _all() => Map<String, dynamic>.from(jsonDecode(p.getString('accounts') ?? '{}'));
  static String _h(String s) => sha256.convert(utf8.encode('daxter::$s')).toString();

  static Future<void> init() async {
    p = await SharedPreferences.getInstance();
    final u = p.getString('session');
    if (u != null && _all().containsKey(u)) _load(u);
  }

  static void _load(String u) {
    profile.value = Map<String, dynamic>.from(_all()[u]);
    current.value = u;
  }

  static String? register(String u, String pw, String name) {
    u = u.trim().toLowerCase();
    if (u.length < 3) return 'Username minimal 3 karakter';
    if (pw.length < 4) return 'Password minimal 4 karakter';
    final a = _all();
    if (a.containsKey(u)) return 'Username sudah dipakai';
    a[u] = {'pass': _h(pw), 'name': name.trim().isEmpty ? u : name.trim(), 'avatar': ''};
    p.setString('accounts', jsonEncode(a));
    p.setString('session', u);
    _load(u);
    return null;
  }

  static String? login(String u, String pw) {
    u = u.trim().toLowerCase();
    final a = _all();
    if (!a.containsKey(u) || a[u]['pass'] != _h(pw)) return 'Username atau password salah';
    p.setString('session', u);
    _load(u);
    return null;
  }

  static void logout() {
    p.remove('session');
    profile.value = {};
    current.value = null;
  }

  static Future<void> update({String? name, String? avatar, String? persona}) async {
    final u = current.value;
    if (u == null) return;
    final a = _all();
    if (name != null && name.trim().isNotEmpty) a[u]['name'] = name.trim();
    if (avatar != null) a[u]['avatar'] = avatar;
    if (persona != null) a[u]['persona'] = persona.trim();
    await p.setString('accounts', jsonEncode(a));
    profile.value = Map<String, dynamic>.from(a[u]);
  }
}

class UserAvatar extends StatelessWidget {
  final double radius;
  const UserAvatar({super.key, required this.radius});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<Map<String, dynamic>>(
        valueListenable: Auth.profile,
        builder: (_, pr, __) {
          final a = (pr['avatar'] ?? '') as String;
          return CircleAvatar(
            radius: radius,
            backgroundColor: purple,
            backgroundImage: a.isEmpty ? null : MemoryImage(base64Decode(a)),
            child: a.isEmpty ? Icon(Icons.person, size: radius, color: Colors.white) : null,
          );
        },
      );
}

class BannerVideo extends StatefulWidget {
  const BannerVideo({super.key});
  @override
  State<BannerVideo> createState() => _BannerVideoState();
}

class _BannerVideoState extends State<BannerVideo> {
  late final VideoPlayerController c;
  bool ok = false;
  @override
  void initState() {
    super.initState();
    c = VideoPlayerController.asset('assets/banner.mp4', videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true));
    c.initialize().then((_) {
      c.setLooping(true);
      c.setVolume(0);
      c.play();
      if (mounted) setState(() => ok = true);
    });
  }

  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => ok
      ? FittedBox(fit: BoxFit.cover, clipBehavior: Clip.hardEdge, child: SizedBox(width: c.value.size.width, height: c.value.size.height, child: VideoPlayer(c)))
      : Container(color: card);
}

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  bool reg = false, hide = true;
  final u = TextEditingController(), pw = TextEditingController(), nm = TextEditingController();
  String? err;

  void submit() => setState(() => err = reg ? Auth.register(u.text, pw.text, nm.text) : Auth.login(u.text, pw.text));

  InputDecoration deco(String h, IconData i) => InputDecoration(
      hintText: h, prefixIcon: Icon(i), filled: true, fillColor: card, border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide.none));

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(children: [
                ClipRRect(borderRadius: BorderRadius.circular(28), child: Image.asset('assets/icon.png', width: 110, height: 110)),
                const SizedBox(height: 16),
                const Text('Daxter Project', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
                Text(reg ? 'Buat akun baru' : 'Masuk ke akunmu', style: const TextStyle(color: Colors.white54)),
                const SizedBox(height: 28),
                if (reg) ...[TextField(controller: nm, decoration: deco('Nama tampilan', Icons.badge_outlined)), const SizedBox(height: 12)],
                TextField(controller: u, decoration: deco('Username', Icons.person_outline)),
                const SizedBox(height: 12),
                TextField(
                  controller: pw,
                  obscureText: hide,
                  onSubmitted: (_) => submit(),
                  decoration: deco('Password', Icons.lock_outline).copyWith(
                      suffixIcon: IconButton(icon: Icon(hide ? Icons.visibility_off : Icons.visibility), onPressed: () => setState(() => hide = !hide))),
                ),
                if (err != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(err!, style: const TextStyle(color: Colors.redAccent))),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    style: FilledButton.styleFrom(padding: const EdgeInsets.all(16), backgroundColor: purple, foregroundColor: Colors.black),
                    onPressed: submit,
                    child: Text(reg ? 'Daftar' : 'Masuk', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                  ),
                ),
                TextButton(
                  onPressed: () => setState(() {
                    reg = !reg;
                    err = null;
                  }),
                  child: Text(reg ? 'Sudah punya akun? Masuk' : 'Belum punya akun? Daftar', style: const TextStyle(color: purple)),
                ),
              ]),
            ),
          ),
        ),
      );
}

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late final TextEditingController nm = TextEditingController(text: '${Auth.profile.value['name'] ?? ''}');
  late final TextEditingController pn = TextEditingController(text: '${Auth.profile.value['persona'] ?? ''}');

  void toast(String t) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));

  Future<void> pick() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 400, imageQuality: 80);
    if (x == null) return;
    await Auth.update(avatar: base64Encode(await x.readAsBytes()));
    toast('Foto profil diganti');
  }

  Future<void> pickCtl(String k) async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 200, imageQuality: 85);
    if (x == null) return;
    await Auth.p.setString('ctl_$k', base64Encode(await x.readAsBytes()));
    setState(() {});
    toast('Gambar tombol diganti');
  }

  Future<void> resetCtl(String k) async {
    await Auth.p.remove('ctl_$k');
    setState(() {});
    toast('Tombol dikembalikan ke default');
  }

  Widget ctlTile(String k, String label) {
    final img = Auth.p.getString('ctl_$k');
    final has = img != null && img.isNotEmpty;
    return GestureDetector(
      onTap: () => pickCtl(k),
      onLongPress: has ? () => resetCtl(k) : null,
      child: Column(children: [
        Container(
          width: 64,
          height: 64,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: card,
            border: Border.all(color: purple, width: 2),
            image: DecorationImage(image: has ? MemoryImage(base64Decode(img)) as ImageProvider : AssetImage('assets/ctl/$k.png'), fit: BoxFit.cover),
          ),
                  ),
        const SizedBox(height: 6),
        Text(label, style: const TextStyle(fontSize: 12, color: Colors.white70)),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
        Center(
          child: Stack(children: [
            const UserAvatar(radius: 56),
            Positioned(
              right: 0,
              bottom: 0,
              child: GestureDetector(
                onTap: pick,
                child: const CircleAvatar(radius: 18, backgroundColor: bg, child: Icon(Icons.camera_alt, size: 18, color: purple)),
              ),
            ),
          ]),
        ),
        const SizedBox(height: 8),
        Center(child: Text('@${Auth.current.value}', style: const TextStyle(color: Colors.white54))),
        const SizedBox(height: 24),
        TextField(
          controller: nm,
          decoration: InputDecoration(
              labelText: 'Nama tampilan', filled: true, fillColor: card, border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide.none)),
        ),
        const SizedBox(height: 14),
        FilledButton(
          style: FilledButton.styleFrom(padding: const EdgeInsets.all(16), backgroundColor: purple, foregroundColor: Colors.black),
          onPressed: () async {
            await Auth.update(name: nm.text);
            toast('Nama disimpan');
          },
          child: const Text('Simpan Nama', style: TextStyle(fontWeight: FontWeight.bold)),
        ),
        const SizedBox(height: 28),
        const Text('PERSONA AI', style: TextStyle(color: Colors.white54, letterSpacing: 2, fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        const Text('Atur gaya, sifat, atau aturan roleplay AI. Ditambahkan ke semua karakter dan berlaku di chat baru.',
            style: TextStyle(color: Colors.white38, fontSize: 13)),
        const SizedBox(height: 10),
        TextField(
          controller: pn,
          minLines: 4,
          maxLines: 8,
          decoration: InputDecoration(
              hintText: 'Contoh: Balas dengan gaya novel, 2-3 paragraf. Selalu panggil aku "Tuan". Jangan keluar dari karakter.',
              filled: true,
              fillColor: card,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide.none)),
        ),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final p in const {
            'Novel': 'Balas dengan gaya novel yang deskriptif, 2-3 paragraf.',
            'Singkat': 'Balas singkat dan padat, maksimal 3 kalimat.',
            'Dingin': 'Bersikap dingin, misterius, dan irit bicara.',
            'Ceria': 'Bersikap ceria, hangat, dan ekspresif.',
          }.entries)
            ActionChip(label: Text(p.key), onPressed: () => setState(() => pn.text = p.value)),
        ]),
        const SizedBox(height: 14),
        Row(children: [
          Expanded(
            child: FilledButton(
              style: FilledButton.styleFrom(padding: const EdgeInsets.all(16), backgroundColor: purple, foregroundColor: Colors.black),
              onPressed: () async {
                await Auth.update(persona: pn.text);
                toast('Persona AI disimpan');
              },
              child: const Text('Simpan Persona', style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ),
          const SizedBox(width: 10),
          OutlinedButton(
            style: OutlinedButton.styleFrom(padding: const EdgeInsets.all(16)),
            onPressed: () async {
              pn.clear();
              await Auth.update(persona: '');
              toast('Persona direset');
            },
            child: const Text('Reset'),
          ),
        ]),
        const SizedBox(height: 28),
        const Text('TOMBOL GAME', style: TextStyle(color: Colors.white54, letterSpacing: 2, fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        const Text('Ketuk untuk ganti gambar dari galeri, tahan untuk kembali ke gambar bawaan.', style: TextStyle(color: Colors.white38, fontSize: 13)),
        const SizedBox(height: 12),
        Wrap(spacing: 16, runSpacing: 14, children: [for (final e in ctlKeys.entries) ctlTile(e.key, e.value)]),
        const SizedBox(height: 28),
        OutlinedButton.icon(
          style: OutlinedButton.styleFrom(padding: const EdgeInsets.all(16), foregroundColor: Colors.redAccent, side: const BorderSide(color: Colors.redAccent)),
          onPressed: Auth.logout,
          icon: const Icon(Icons.logout),
          label: const Text('Keluar'),
        ),
      ]);
}

// ---------------- GAME: DEAD ZONE COMMANDO ----------------
class GamePage extends StatefulWidget {
  const GamePage({super.key});
  @override
  State<GamePage> createState() => _GamePageState();
}

const ctlKeys = {'l': '◀ Kiri', 'd': '▼ Jongkok', 'r': '▶ Kanan', 'j': 'A Lompat', 'f': 'B Tembak'};

class _GamePageState extends State<GamePage> {
  late final WebViewController c;
  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    c = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..setNavigationDelegate(NavigationDelegate(onPageFinished: (_) {
        for (final k in ctlKeys.keys) {
          final img = Auth.p.getString('ctl_$k');
          if (img != null && img.isNotEmpty) c.runJavaScript('setCtl(${jsonEncode(k)}, ${jsonEncode('data:image/png;base64,$img')})');
        }
      }))
      ..loadFlutterAsset('assets/deadzone.html');
  }

  @override
  void dispose() {
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        body: Stack(children: [
          Positioned.fill(child: WebViewWidget(controller: c)),
          Positioned(
            top: 6,
            left: 6,
            child: IconButton(
              style: IconButton.styleFrom(backgroundColor: Colors.black54),
              icon: const Icon(Icons.close, color: Colors.white),
              onPressed: () => Navigator.pop(context),
            ),
          ),
        ]),
      );
}

// ---------------- TOOLS: DOWNLOAD TIKTOK (tikwm, tanpa watermark) ----------------
class TikTokPage extends StatefulWidget {
  const TikTokPage({super.key});
  @override
  State<TikTokPage> createState() => _TikTokPageState();
}

class _TikTokPageState extends State<TikTokPage> {
  final url = TextEditingController();
  bool loading = false, saving = false;
  String? err;
  Map<String, dynamic>? d;

  void toast(String t) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));
  String abs(dynamic u) {
    final s = '${u ?? ''}';
    if (s.isEmpty) return '';
    return s.startsWith('http') ? s : 'https://www.tikwm.com$s';
  }

  String get videoUrl => abs(d!['hdplay'] ?? d!['play']);

  Future<void> paste() async {
    final c = await Clipboard.getData('text/plain');
    if (c?.text != null) setState(() => url.text = c!.text!.trim());
  }

  Future<void> fetch() async {
    final link = url.text.trim();
    if (link.isEmpty) return;
    setState(() {
      loading = true;
      err = null;
      d = null;
    });
    try {
      final r = await http.get(Uri.https('www.tikwm.com', '/api/', {'url': link, 'hd': '1'})).timeout(const Duration(seconds: 30));
      final j = jsonDecode(r.body);
      if (j['code'] != 0 || j['data'] == null) throw Exception(j['msg'] ?? 'Gagal mengambil video');
      setState(() => d = Map<String, dynamic>.from(j['data']));
    } catch (e) {
      setState(() => err = '$e'.replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> save() async {
    setState(() => saving = true);
    try {
      if (!await Gal.hasAccess(toAlbum: true)) await Gal.requestAccess(toAlbum: true);
      final r = await http.get(Uri.parse(videoUrl)).timeout(const Duration(minutes: 3));
      if (r.statusCode != 200) throw Exception('Download gagal (${r.statusCode})');
      final dir = await getTemporaryDirectory();
      final f = File('${dir.path}/tt_${DateTime.now().millisecondsSinceEpoch}.mp4');
      await f.writeAsBytes(r.bodyBytes);
      await Gal.putVideo(f.path, album: 'Daxter Project');
      await f.delete();
      toast('Tersimpan di galeri (album Daxter Project)');
    } catch (e) {
      toast('Gagal menyimpan: $e');
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final author = d?['author'] is Map ? d!['author'] : null;
    return ListView(padding: const EdgeInsets.all(16), children: [
      TextField(
        controller: url,
        onSubmitted: (_) => fetch(),
        decoration: InputDecoration(
          hintText: 'Tempel link TikTok...',
          filled: true,
          fillColor: card,
          prefixIcon: const Icon(Icons.link),
          suffixIcon: IconButton(icon: const Icon(Icons.content_paste), onPressed: paste),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide.none),
        ),
      ),
      const SizedBox(height: 12),
      FilledButton.icon(
        style: FilledButton.styleFrom(padding: const EdgeInsets.all(16), backgroundColor: purple, foregroundColor: Colors.black),
        onPressed: loading ? null : fetch,
        icon: loading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.search),
        label: const Text('Ambil Video', style: TextStyle(fontWeight: FontWeight.bold)),
      ),
      if (err != null) Padding(padding: const EdgeInsets.only(top: 14), child: Text(err!, style: const TextStyle(color: Colors.redAccent))),
      if (d != null) ...[
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(24)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (abs(d!['cover']).isNotEmpty)
              ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Image.network(abs(d!['cover']), height: 220, width: double.infinity, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox(height: 60)),
              ),
            const SizedBox(height: 10),
            if (author != null) Text('@${author['unique_id'] ?? ''} · ${author['nickname'] ?? ''}', style: const TextStyle(color: purple, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text('${d!['title'] ?? ''}', maxLines: 3, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                style: FilledButton.styleFrom(padding: const EdgeInsets.all(16), backgroundColor: green, foregroundColor: Colors.black),
                onPressed: saving ? null : save,
                icon: saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.download),
                label: Text(saving ? 'Mengunduh...' : 'Simpan Tanpa Watermark', style: const TextStyle(fontWeight: FontWeight.bold)),
              ),
            ),
            TextButton.icon(
              onPressed: () {
                Clipboard.setData(ClipboardData(text: videoUrl));
                toast('Link video disalin');
              },
              icon: const Icon(Icons.copy, size: 18),
              label: const Text('Salin link video'),
            ),
          ]),
        ),
      ],
    ]);
  }
}

// ---------------- TOOLS: TEMP MAIL (Sylvatica API) ----------------
dynamic _findFirst(dynamic o, bool Function(dynamic v, String k) pred, [String key = '', int depth = 0]) {
  if (depth > 6 || o == null) return null;
  if (pred(o, key)) return o;
  if (o is Map) {
    for (final e in o.entries) {
      final r = _findFirst(e.value, pred, '${e.key}', depth + 1);
      if (r != null) return r;
    }
  } else if (o is List) {
    for (final v in o) {
      final r = _findFirst(v, pred, key, depth + 1);
      if (r != null) return r;
    }
  }
  return null;
}

class TempMailPage extends StatefulWidget {
  const TempMailPage({super.key});
  @override
  State<TempMailPage> createState() => _TempMailPageState();
}

class _TempMailPageState extends State<TempMailPage> {
  static final emailRe = RegExp(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}');
  String get kE => 'tm_${Auth.current.value}_email';
  String get kT => 'tm_${Auth.current.value}_token';
  String? email, token, err;
  List<Map<String, String>> inbox = [];
  bool busy = false;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    email = Auth.p.getString(kE);
    token = Auth.p.getString(kT);
    if (email != null) check();
    timer = Timer.periodic(const Duration(seconds: 15), (_) {
      if (email != null && !busy) check(quiet: true);
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  void toast(String t) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));

  Future<dynamic> call(Map<String, String> q) async {
    final r = await http.get(Uri.parse(tmUrl).replace(queryParameters: {...q, 'apikey': apiKey})).timeout(const Duration(seconds: 30));
    final j = jsonDecode(r.body);
    if (j is Map && (j['status'] == false || j['success'] == false)) throw Exception(j['message'] ?? j['error'] ?? 'API menolak permintaan');
    return j;
  }

  Future<void> create() async {
    setState(() {
      busy = true;
      err = null;
    });
    try {
      final j = await call({'action': 'create'});
      final em = _findFirst(j, (v, k) => v is String && RegExp('mail|address', caseSensitive: false).hasMatch(k) && emailRe.hasMatch(v)) ??
          _findFirst(j, (v, k) => v is String && emailRe.hasMatch(v));
      if (em == null) throw Exception('API tidak mengembalikan alamat email');
      final addr = emailRe.firstMatch(em as String)!.group(0)!;
      final tk = _findFirst(j, (v, k) => (v is String || v is num) && '$v'.trim().isNotEmpty && RegExp('token|session|hash', caseSensitive: false).hasMatch(k)) ??
          _findFirst(j, (v, k) => (v is String || v is num) && RegExp(r'^(id|uid|inbox_id|mail_id)$', caseSensitive: false).hasMatch(k));
      email = addr;
      token = tk != null ? '$tk' : addr;
      await Auth.p.setString(kE, email!);
      await Auth.p.setString(kT, token!);
      inbox = [];
    } catch (e) {
      err = '$e'.replaceFirst('Exception: ', '');
    }
    if (mounted) setState(() => busy = false);
  }

  String strip(String s) =>
      s.replaceAll(RegExp(r'<style[\s\S]*?</style>', caseSensitive: false), '').replaceAll(RegExp(r'<[^>]*>'), ' ').replaceAll('&nbsp;', ' ').replaceAll(RegExp(r'\s+'), ' ').trim();

  String pick(dynamic m, List<String> keys) {
    if (m is! Map) return '';
    for (final k in keys) {
      final v = m[k];
      if (v is String && v.trim().isNotEmpty) return v;
      if (v is Map) {
        final i = v['address'] ?? v['email'] ?? v['name'] ?? v['text'];
        if (i is String && i.trim().isNotEmpty) return i;
      }
    }
    return '';
  }

  Future<void> check({bool quiet = false}) async {
    if (token == null) return;
    if (!quiet) setState(() => busy = true);
    try {
      final j = await call({'action': 'check', 'token': token!});
      final list = j is List ? j : (_findFirst(j, (v, k) => v is List) as List? ?? []);
      inbox = list.map<Map<String, String>>((m) {
        if (m is String) return {'from': '', 'subject': '', 'body': strip(m), 'date': ''};
        return {
          'from': pick(m, ['from', 'sender', 'from_email', 'fromAddress', 'email']),
          'subject': pick(m, ['subject', 'title', 'judul']),
          'body': strip(pick(m, ['text', 'body', 'content', 'message', 'intro', 'preview', 'snippet', 'html'])),
          'date': pick(m, ['date', 'created_at', 'createdAt', 'time', 'received_at', 'receivedAt', 'timestamp']),
        };
      }).toList();
      err = null;
    } catch (e) {
      if (!quiet) err = '$e'.replaceFirst('Exception: ', '');
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(24), border: Border.all(color: Colors.white10)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('EMAIL SEMENTARA', style: TextStyle(color: Colors.white54, letterSpacing: 2, fontWeight: FontWeight.bold, fontSize: 12)),
            const SizedBox(height: 8),
            if (email != null)
              Row(children: [
                Expanded(child: SelectableText(email!, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: purple))),
                IconButton(
                  icon: const Icon(Icons.copy),
                  onPressed: () {
                    Clipboard.setData(ClipboardData(text: email!));
                    toast('Email disalin');
                  },
                ),
              ])
            else
              const Text('Belum ada email. Tekan tombol di bawah.', style: TextStyle(color: Colors.white54)),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(padding: const EdgeInsets.all(14), backgroundColor: purple, foregroundColor: Colors.black),
                  onPressed: busy ? null : create,
                  icon: const Icon(Icons.add),
                  label: Text(email == null ? 'Buat Email' : 'Email Baru', style: const TextStyle(fontWeight: FontWeight.bold)),
                ),
              ),
              if (email != null) ...[
                const SizedBox(width: 10),
                OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(padding: const EdgeInsets.all(14)),
                  onPressed: busy ? null : () => check(),
                  icon: busy ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.refresh),
                  label: const Text('Refresh'),
                ),
              ],
            ]),
            if (err != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(err!, style: const TextStyle(color: Colors.redAccent))),
          ]),
        ),
        const SizedBox(height: 18),
        if (email != null) ...[
          const Text('KOTAK MASUK', style: TextStyle(color: Colors.white54, letterSpacing: 2, fontWeight: FontWeight.bold, fontSize: 12)),
          const SizedBox(height: 4),
          const Text('Diperbarui otomatis tiap 15 detik.', style: TextStyle(color: Colors.white38, fontSize: 12)),
          const SizedBox(height: 10),
          if (inbox.isEmpty)
            const Padding(padding: EdgeInsets.all(24), child: Center(child: Text('Belum ada pesan', style: TextStyle(color: Colors.white38))))
          else
            for (final m in inbox)
              Card(
                color: card,
                margin: const EdgeInsets.only(bottom: 10),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                child: ListTile(
                  title: Text(m['subject']!.isEmpty ? '(tanpa subjek)' : m['subject']!, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text('${m['from']}\n${m['body']}', maxLines: 3, overflow: TextOverflow.ellipsis),
                  isThreeLine: true,
                  onTap: () => showDialog(
                    context: context,
                    builder: (_) => AlertDialog(
                      backgroundColor: card,
                      title: Text(m['subject']!.isEmpty ? '(tanpa subjek)' : m['subject']!),
                      content: SingleChildScrollView(child: SelectableText('Dari: ${m['from']}\n${m['date']}\n\n${m['body']}')),
                      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Tutup'))],
                    ),
                  ),
                ),
              ),
        ],
      ]);
}
