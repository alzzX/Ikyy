package com.daxter.project

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
